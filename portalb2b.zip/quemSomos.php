<?php include 'headerLogado.php' ?>
			
	<div id="divBreadcrumbs" class="row">
		<div class="col-md-1"></div>
		<div class="col-md-4"><a href="telaInicialLogado.php">Início</a> > <strong>Quem somos</strong></div>
		<div class="col-md-7 text-center"></div>
	</div>
	<div class="row">
		<div class="col-md-1"></div>
		<div class="col-md-4"><h1>Quem somos</h1></div>
		<div class="col-md-7 text-center"></div>
	</div>
	<br>
	<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-4">
			<p class="text-justify">
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla semper, lorem in feugiat convallis, neque ligula accumsan libero, a consequat sapien tellus eu diam. Praesent sit amet lacus lorem. Praesent non nunc et metus efficitur blandit at ut tortor. Praesent porta viverra tristique. Nam nec erat vitae risus sodales accumsan. Suspendisse potenti. Curabitur aliquam, massa vel vulputate volutpat, lorem velit porta diam, in posuere felis justo nec ipsum. Mauris commodo ipsum aliquam, euismod libero sit amet, maximus odio. Pellentesque a eleifend nibh. Proin ut erat sit amet enim vehicula porttitor in ac enim.<br>
			<br>
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla semper, lorem in feugiat convallis, neque ligula accumsan libero, a consequat sapien tellus eu diam. Praesent sit amet lacus lorem. Praesent non nunc et metus efficitur blandit at ut tortor. Praesent porta viverra tristique. Nam nec erat vitae risus sodales accumsan. Suspendisse potenti. Curabitur aliquam, massa vel vulputate volutpat, lorem velit porta diam, in posuere felis justo nec ipsum. Mauris commodo ipsum aliquam, euismod libero sit amet, maximus odio. Pellentesque a eleifend nibh. Proin ut erat sit amet enim vehicula porttitor in ac enim.
			</p>
		</div>
		<div class="col-md-4">
			<p class="text-justify">
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla semper, lorem in feugiat convallis, neque ligula accumsan libero, a consequat sapien tellus eu diam. Praesent sit amet lacus lorem. Praesent non nunc et metus efficitur blandit at ut tortor. Praesent porta viverra tristique. Nam nec erat vitae risus sodales accumsan. Suspendisse potenti. Curabitur aliquam, massa vel vulputate volutpat, lorem velit porta diam, in posuere felis justo nec ipsum. Mauris commodo ipsum aliquam, euismod libero sit amet, maximus odio. Pellentesque a eleifend nibh. Proin ut erat sit amet enim vehicula porttitor in ac enim.<br>
			<br>
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla semper, lorem in feugiat convallis, neque ligula accumsan libero, a consequat sapien tellus eu diam. Praesent sit amet lacus lorem. Praesent non nunc et metus efficitur blandit at ut tortor. Praesent porta viverra tristique. Nam nec erat vitae risus sodales accumsan. Suspendisse potenti. Curabitur aliquam, massa vel vulputate volutpat, lorem velit porta diam, in posuere felis justo nec ipsum. Mauris commodo ipsum aliquam, euismod libero sit amet, maximus odio. Pellentesque a eleifend nibh. Proin ut erat sit amet enim vehicula porttitor in ac enim.
			</p>
		</div>
		<div class="col-md-2"></div>
	</div>
	<br>
	<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-8">
			<p class="text-justify">
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla semper, lorem in feugiat convallis, neque ligula accumsan libero, a consequat sapien tellus eu diam. Praesent sit amet lacus lorem. Praesent non nunc et metus efficitur blandit at ut tortor. Praesent porta viverra tristique. Nam nec erat vitae risus sodales accumsan. Suspendisse potenti. Curabitur aliquam, massa vel vulputate volutpat, lorem velit porta diam, in posuere felis justo nec ipsum. Mauris commodo ipsum aliquam, euismod libero sit amet, maximus odio. Pellentesque a eleifend nibh. Proin ut erat sit amet enim vehicula porttitor in ac enim. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla semper, lorem in feugiat convallis, neque ligula accumsan libero, a consequat sapien tellus eu diam. Praesent sit amet lacus lorem. Praesent non nunc et metus efficitur blandit at ut tortor. Praesent porta viverra tristique. Nam nec erat vitae risus sodales accumsan. Suspendisse potenti. Curabitur aliquam, massa vel vulputate volutpat, lorem velit porta diam, in posuere felis justo nec ipsum. Mauris commodo ipsum aliquam, euismod libero sit amet, maximus odio. Pellentesque a eleifend nibh. Proin ut erat sit amet enim vehicula porttitor in ac enim.
			</p>
		</div>
		<div class="col-md-2"></div>
	</div>
	<br>
	<br>
	<br>
<?php include 'footerLogado.php'?>