</div>
	<!-- RODAPÉ -->
	<div id="divFooter" class="row">
		<div class="col-md-1">	
		</div>
		<div class="col-md-2">
			<h3>ACESSO RÁPIDO</h3>
			<ul class="nav nav-pills nav-stacked">
				<li><a href="#">Início</a></li>
				<li><a href="#">Produtos</a></li>
				<li><a href="#">Quem somos</a></li>
				<li><a href="#">Fale conosco</a></li>
			</ul>
		</div>
		<div class="col-md-3 text-center">
			<h3>ONDE ESTAMOS</h3>
			<strong class="text-center">Mato Grosso do Sul</strong><br>
			Av. João Batista Fernandes, 1415<br>
			Polo Empresarial Oeste<br>
			Campo Grande - MS<br>
			Fone: (67) 3378-2000<br>
			Fax: (67) 3378-2001<br>
		</div>
		<div class="col-md-3 text-center">
			<h3>&nbsp;</h3>
			<strong class="text-center">Mato Grosso</strong><br>
			R. Ipê Amarelo, QD 06 - LT 0<br>
			Bairro Novo Mundo<br>
			Várzea Grande - MT<br>
			Fone: (65) 3688-3900<br>
			Fax: (65) 3688-3900<br>
		</div>
		<div class="col-md-2 text-center">
			<h3>Fale conosco</h3>
			<span>
			De segunda à sexta<br>
			Das 08h às 18h<br>
			<h1>(11) 4935-2344</h1>
			compras@distlopes.com.br<br>
			</span>
		</div>	
		<div class="col-md-1"></div>
	</div>
	
	<!-- SOCKET DO RODAPÉ -->
	<div id="divSocket" class="row">
		<div class="col-md-12 text-center">
		<img src="img/maxima.png" width="25" height="21">&nbsp;&nbsp;&nbsp;Máxima Sistemas, Versão 4.8.2.3 , Copyright © 2008-2017 Todos os direitos reservados.
		</div>
	</div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>