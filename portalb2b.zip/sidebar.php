	<!--  CONTAINER PRINCIPAL COM SIDEBAR E CONTEÚDO  -->
	<div class="row">
			<div class="col-md-1"></div>
			<div id="divSidebar" class="col-md-2">
				<h3>DEPARTAMENTOS</h3>
				<ul class="nav navbar-nav">
					<li><a href="#">ABRASIVOS<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">ACESSÓRIOS PARA BANHEIRO<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">ADESIVOSOS<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">AGROPECUÁRIA E PET SHOP<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">ELÉTRICA<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">EPI-SEGURANÇA<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">FERRAGENS<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">FERRAMENTAS ELÉTRICAS<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">ABRASIVOS<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">ACESSÓRIOS PARA BANHEIRO<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">ADESIVOSOS<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">AGROPECUÁRIA E PET SHOP<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">ELÉTRICA<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">EPI-SEGURANÇA<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">FERRAGENS<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">FERRAMENTAS ELÉTRICAS<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li><li ><a href="#">ABRASIVOS<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">ACESSÓRIOS PARA BANHEIRO<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">ADESIVOSOS<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">AGROPECUÁRIA E PET SHOP<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">ELÉTRICA<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">EPI-SEGURANÇA<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">FERRAGENS<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">FERRAMENTAS ELÉTRICAS<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>       <li ><a href="#">ABRASIVOS<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">ACESSÓRIOS PARA BANHEIRO<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">ADESIVOSOS<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">AGROPECUÁRIA E PET SHOP<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">ELÉTRICA<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">EPI-SEGURANÇA<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">FERRAGENS<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
					<li ><a href="#">FERRAMENTAS ELÉTRICAS<img class="text-right" src="img/icon/seta-direita.png" width="15" height="15"></a></li>
				  </ul>
			</div>